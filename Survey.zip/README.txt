1-The project was created in php laravel with bootstrap and bootstrap was chosen to be compatible with mobile screens
2-The project was created in two parts: server side and client side
3-The project is divided into two parts, the customer part and the manager part
4-To enter the client part, you can add /home to access the client control
5-To access the admin part, you can add /admin and type 
user:admin@shangrila.gov.un 
pwd :shangrila@2021$
6- You can also test the task2 of the postman after running the project
7- Database name survey.sql
