

<?php $__env->startSection('content'); ?>
<link href='https://fonts.googleapis.com/css?family=Cairo' rel='stylesheet'>
<script src="https://code.jquery.com/jquery-3.5.0.js"></script>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Questions')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    Choose the question and then choose the appropriate answer
                    <br>
                    <hr>
                    Choose the question
                    <ul style="list-style-type:none;">
                    <select class="browser-default custom-select" id="question" name="question">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->text); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                    </select>
                      
                        
                    </ul> 
                   Add - Update Question
                    <br>
                    <ul style="list-style-type:none;">
                    
                <div class="form-outline">
                <input type="text" id="answer" name="answer" class="form-control" />
               
                </div>
                        
                    </ul> 
                    <div class="container">
                        <div class="row">
                        <div class="col-sm-3">
                        </div>
                            <div class="col-sm-9">
                            <button type="button" id="save" name="save" class="btn btn-primary">Save</button>
                            <button type="button" id="delete" name="delete" class="btn btn-primary">delete</button>
                            <button type="button" id="update" name="update" class="btn btn-primary">update</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="fetch" name="fetch"></div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
       
       
        $("#question").on("change", function() {
            $('#fetch').html( '<div class="alert alert-warning" role="alert">Please write the answer</div>');
        });
         $("#save").on("click", function() {
            var question_id = $('#question').val();
            var value = $('#answer').val();
            $.ajax({
        type: "GET",
                url: "/createquestion",
                dataType: "json",
                data:{
        "_token": "<?php echo e(csrf_token()); ?>",
        question_id:question_id,
        text:value,
      
      },
     
      beforeSend: function() {    
     
              },
                success: function (response) {
                    $('#fetch').html( '<div class="alert alert-primary" role="alert">saved</div>');
                }
       
           
    
   
});
          });
          $("#delete").on("click", function() {
            var question_id = $('#question').val();
            var value = $('#answer').val();
            $.ajax({
        type: "GET",
                url: "/deletequestion",
                dataType: "json",
                data:{
        "_token": "<?php echo e(csrf_token()); ?>",
        question_id:question_id,
        text:value,
      
      },
     
      beforeSend: function() {    
     
              },
                success: function (response) {
                    $('#fetch').html( '<div class="alert alert-primary" role="alert">Updated</div>');
                }
       
           
    
   
});
          });
          $("#update").on("click", function() {
            var question_id = $('#question').val();
            var value = $('#answer').val();
            $.ajax({
        type: "GET",
                url: "/updatequestion",
                dataType: "json",
                data:{
        "_token": "<?php echo e(csrf_token()); ?>",
        question_id:question_id,
        text:value,
      
      },
     
      beforeSend: function() {    
     
              },
                success: function (response) {
                    $('#fetch').html( '<div class="alert alert-primary" role="alert">Updated</div>');
                }
       
           
    
   
});
          });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saad\Desktop\Survey\resources\views/admin/questions.blade.php ENDPATH**/ ?>