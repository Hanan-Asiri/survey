<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                    <ul style="list-style-type:none;">
                        <li><h4><a href="<?php echo e(route('my-getquestionspage')); ?>">Questions</a></h4></li>
                        <li><h4><a href="<?php echo e(route('my-getmyAccount')); ?>">My Account</a></h4></li>
                        <li><h4><a href="<?php echo e(route('my-getmyanswre')); ?>">my answers</a></h4></li>
                        
                    </ul>  
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Survey\resources\views/home.blade.php ENDPATH**/ ?>